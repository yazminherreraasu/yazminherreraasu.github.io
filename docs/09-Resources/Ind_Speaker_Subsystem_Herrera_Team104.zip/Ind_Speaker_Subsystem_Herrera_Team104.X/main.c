 /*
 * MAIN Generated Driver File
 * 
 * @file main.c
 * 
 * @defgroup main MAIN
 * 
 * @brief This is the generated driver implementation file for the MAIN driver.
 *
 * @version MAIN Driver Version 1.0.2
 *
 * @version Package Version: 3.1.2
*/

// Yazmin Herrera
// Individual Speaker Subsystem
// 11/30/26

 
#include "mcc_generated_files/system/system.h"
#include <stdint.h>
#include <xc.h>
#define _XTAL_FREQ 64000000UL //defined by MCC, telling pic is running at 64MHz to match clock control setting 

uint8_t speaker_active = 0; //1=speaker ON and 0=speaker OFF
uint8_t logan_last_state = 0; //stores last signal from Logan
uint8_t debug_last_state = 1; //stores if debug button was pressed
uint8_t stop_last_state = 1; //remembers if speaker OFF was pressed


int main(void)
{
    SYSTEM_Initialize();
    
    speaker_active = 0;

    logan_last_state = IO_RB2_GetValue();
    debug_last_state = IO_RD2_GetValue();
    stop_last_state = IO_RD4_GetValue();

    DAC1_SetOutput(0);
    IO_RD3_SetLow();


    while(1)
    {
        uint8_t logan_trigger = IO_RB2_GetValue();
        uint8_t debug_button = IO_RD2_GetValue();

        //===============section to check if there's a new HIGH signal from Logan===================
        if (logan_trigger == 1 && logan_last_state == 0)
        {
            speaker_active = 1;
        }

        //==============section to check if the debug button was pressed========================
        if (debug_button == 0 && debug_last_state == 1)
        {
            speaker_active = 1;
        }

        //============section to save the current state of Logan's signal=====================
        logan_last_state = logan_trigger;
        debug_last_state = debug_button;
        
        uint8_t stop_button = IO_RD4_GetValue();

        //============section to check if the speaker OFF button was pressed==============
        if (stop_button == 0 && stop_last_state == 1)
        {
            speaker_active = 0;
        }

        //==================section to save the current button state=================
        stop_last_state = stop_button;
        // Debug LED
        if (speaker_active == 1)
        {
            IO_RD3_SetHigh();
        }
        else
        {
            IO_RD3_SetLow();
        }
        //=================section for speaker audio output======================
        if (speaker_active == 1)
        {
            DAC1_SetOutput(255);
            __delay_us(500);

            DAC1_SetOutput(0);
            __delay_us(500);
        }
        else
        {
            DAC1_SetOutput(0);
        }    
        
    }    
}